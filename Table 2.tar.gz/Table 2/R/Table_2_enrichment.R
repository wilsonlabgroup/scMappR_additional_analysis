library(scMappR)

# Loading data


#### This is the code required for Table 2
library(scMappR)

#Loading Data
load("data/SRA653146_signature_matrix_pval.Rdata")



# Adding extended cell-type markers
sup4_Duraes <- c("Foxp3", "Il2ra", "Ikzf2", "Itgae", "Cd83", "Il10",
                 "Areg", "Tnfrsf4", "Tnfrsf9", "Klrg1", "Ctla4", "Il1rl1",
                 "Tnfrsf18", "Rgs16", "Rgs2", "Gata3", "Nkg7", "Ifng", "Ccl5", "Ccl4",
                 "Itgb1", "Cd7", "Tmem176a", "Tmem176b", "Il17a", "Rora", "Ccr7", "Lef1",
                 "Satb1", "Klf2", "Igfbp4", "Il7r", "Tcf7", "Sell")

# Running  enrichment of T cells with tabula muris signature matrix.
table2 <- tissue_scMappR_custom(sup4_Duraes, SRA653146_sig_pval, "sup4_duraes", toSave = FALSE)

# Saving output table
write.table(table2$single_celltype_preferences, file = "Table2.txt", quote = FALSE, row.names = FALSE, col.names = TRUE)
