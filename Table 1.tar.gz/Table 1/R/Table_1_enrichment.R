library(scMappR)

# Loading data


#### This is the code required for Table 1
library(scMappR)

#Loading Data
load("Cdata/celltype_path.Rdata")

MacroDend <- celltype_path$`Macrophage, Dendritic`$ranks

# Adding extended cell-type markers
sup4_Duraes <- c("Foxp3", "Il2ra", "Ikzf2", "Itgae", "Cd83", "Il10",
                 "Areg", "Tnfrsf4", "Tnfrsf9", "Klrg1", "Ctla4", "Il1rl1",
                 "Tnfrsf18", "Rgs16", "Rgs2", "Gata3", "Nkg7", "Ifng", "Ccl5", "Ccl4",
                 "Itgb1", "Cd7", "Tmem176a", "Tmem176b", "Il17a", "Rora", "Ccr7", "Lef1",
                 "Satb1", "Klf2", "Igfbp4", "Il7r", "Tcf7", "Sell")

# Check if overlapping DEGs are significantly higher than average
wilcox.test(MacroDend[intersect(sup4_Duraes, rownames(MacroDend)),"rank_change"], MacroDend$rank_change[!(rownames(MacroDend) %in% intersect(sup4_Duraes, rownames(MacroDend)))], alternative = "less")

# Test enrichment of all mouse markers
tst <- tissue_by_celltype_enrichment(sup4_Duraes, "mouse", rda_path = "")

# Output matrix
Duraes_sup4_genes <- tst[1:15,c("name", "term_size", "intersect_size", "input_length", "fdr", "OR")]
Duraes_sup4_genes_names <- do.call("rbind",strsplit(tochr(Duraes_sup4_genes$name), "(:  )|(_and_)|_"))
bound_Duraes <- cbind(Duraes_sup4_genes_names, Duraes_sup4_genes)
colnames(bound_Duraes) <- c("SRA_ID", "Tissue", "CellMarker_Label", "Panglao_Label", "ClusterNumber", colnames(Duraes_sup4_genes) )
write.table(bound_Duraes, file = "Table1.txt", row.names = FALSE, col.names = TRUE, sep = "\t", quote = FALSE)
