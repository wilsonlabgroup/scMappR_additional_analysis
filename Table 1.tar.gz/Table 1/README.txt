This folder provides all of the scripts and data to generate the table tha became "Table 1" in Sokolowski et al., “Single-cell mapper (scMappR): calibrating bulk RNA-seq differential gene expression results with scRNA-seq data”

It uses the tissue_by_celltype_enrichment that requires the internet.